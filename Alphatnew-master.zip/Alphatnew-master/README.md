# alphat-new-generation
Forked version of LineAlphat JS (Selfbot) #DEV #14/10/2017 #12PM
<br>LineAlphat -> https://github.com/alfathdirk/LineAlphatJS<br><br>Status: Very Good

<hr>

# require node >= v8.x.x
check your nodejs version
`node -v`
[upgrade nodejs](https://google.com/)


How to run bot for the first time ?
------
- `git clone https://gitlab.com/m.rakha.f/alphat-new-generation.git`
- `cd alphat-new-generation && npm install`
- `insert your admin mid in main.js`
- `npm start`

IMPORTANT
------
**PLEASE DO `npm i` FOR THIS UPDATE -> #14/10/2017**

Still work :construction_worker:
----
**CHANGELOG**
- Bug fixed
- AutoLike
- AutoComment
- Broadcast
- CreateAlbum
- GroupInfo

**TO - DO**
- Add keyword for (Send Image & Broadcast)
- Send VN
- Send Video

CMD / KEYWORD
------
**type !key for the keyword**

How to activate AutoLike feature ?
------
- `1. Goto src/bot.js`
- `2. Then find this " //LINE.aLike() //AutoLike (CAUSE LAG) " (without quotes)`
- `3. Change into this " LINE.aLike() " (without quotes)`
- `4. DONE`

Author
------
[@alfathdirk](https://instagram.com/alfathdirk) (LINE ALPHAT JS)<br>
[@GoogleX](https://fb.me/m.rakha.f) (LINE ALPHAT-FORK)

Contact Me / Need Help ?
------
[@LINE](http://line.me/ti/p/MB6mnZWbu_) (GoogleX)

FAQ (Frequently Asked Questions)
------
Q: "How to run this bot 24/7 ?"<br>
A: "Use Termux on your android phone, and run this bot on it"<br>

Q: "Im using termux, and i have problem with `npm i` . What i gonna do ?"<br>
A: "After you clone with `git clone`, then `cd my` and you got problem with `npm i`. All you gonna do is `unzip node.js.zip`"<br>

Q: "How to edit some script on Termux ?"<br>
A: "I recommend you to use text editor terminal edition like vim or nano"<br>

Q: "Best keyboard for Termux ?"<br>
A: "I recommend you to use Hacker's Keyboard on Playstore"<br>

Q: "How to install latest nodejs on termux ?"<br>
A: "Simple, `pkg install nodejs-current`"
